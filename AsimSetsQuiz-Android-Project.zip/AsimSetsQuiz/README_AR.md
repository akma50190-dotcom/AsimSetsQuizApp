# اختبار رموز المجموعات — المطور عاصم الاحمر 👨‍💻

هذا مشروع Android كامل لنسخة الاختبار الحالية. التطبيق يفتح صفحة الاختبار داخل WebView ويعمل بدون إنترنت بعد التثبيت.

## بناء APK في Android Studio
1. افتح المجلد `AsimSetsQuiz` في Android Studio.
2. انتظر مزامنة Gradle.
3. اختر **Build > Build APK(s)**.
4. ستجد ملف APK في:
   `app/build/outputs/apk/debug/app-debug.apk`

## ملاحظات
- اسم الحزمة: `com.asim.setsquiz`
- الحد الأدنى: Android 6.0 (API 23)
- اسم التطبيق: اختبار رموز المجموعات
- المطور داخل التطبيق: عاصم الاحمر
